package com.calculator;

import com.calculator.operation.*;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

/*
 *@author Shaofeng
 *@date 2020/12/18 17:14
 *note:
 */public class OperationFactoryTest {

    @Test
    public void getOperation() {

        CalOperation co = OperationFactory.getOperation("1");
        Assert.assertTrue(co instanceof DefaultOperation);

        CalOperation plus = OperationFactory.getOperation("+");
        Assert.assertTrue(plus instanceof AddOperation);

        CalOperation minus = OperationFactory.getOperation("-");
        Assert.assertTrue(minus instanceof MinusOperation);

        CalOperation mutip = OperationFactory.getOperation("*");
        Assert.assertTrue(mutip instanceof MultipOperation);

        CalOperation divid = OperationFactory.getOperation("/");
        Assert.assertTrue(divid instanceof DividOperation);

        CalOperation undo = OperationFactory.getOperation("undo");
        Assert.assertTrue(undo instanceof UndoOperation);

        CalOperation clear = OperationFactory.getOperation("clear");
        Assert.assertTrue(clear instanceof ClearOperation);

        CalOperation sqrt = OperationFactory.getOperation("sqrt");
        Assert.assertTrue(sqrt instanceof SqrtOperation);

        CalOperation unKnown = OperationFactory.getOperation("&");
        Assert.assertTrue(unKnown instanceof UnknownOperation);
    }
}