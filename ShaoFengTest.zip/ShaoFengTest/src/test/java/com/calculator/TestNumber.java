package com.calculator;

/*
 *@author Shaofeng
 *@date 2020/12/18 16:55
 *note:
 */
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestNumber {

    public static void main(String[] args) {
        System.out.println(isNumeric("+1"));
        System.out.println(isNumeric("-1"));
        System.out.println(isNumeric("-"));
        System.out.println(isNumeric("+"));
    }

    public static boolean isNumeric(String str) {
        //Pattern pattern = Pattern.compile("[0-9]*");
        if("-".equals(str)) return false;
        if("+".equals(str)) return false;
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        Matcher isNum = pattern.matcher(str);
        if (!isNum.matches()) {
            return false;
        }
        return true;

    }
}
