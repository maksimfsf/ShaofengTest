package com.calculator;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Stack;

import static org.junit.Assert.*;

/*
 *@author Shaofeng
 *@date 2020/12/18 16:12
 *note:
 */public class OperatorUtilTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void isNumeric() {
        Assert.assertTrue(OperatorUtil.isNumeric("12"));
        Assert.assertTrue(OperatorUtil.isNumeric(""));
        Assert.assertFalse(OperatorUtil.isNumeric(" "));
        Assert.assertFalse(OperatorUtil.isNumeric("abc"));
    }

    @Test
    public void isValidInput() {
        Assert.assertTrue(OperatorUtil.isValidInput("12"));
        Assert.assertTrue(OperatorUtil.isValidInput("*"));
        Assert.assertFalse(OperatorUtil.isValidInput(" "));
        Assert.assertFalse(OperatorUtil.isValidInput("abc"));
    }

    @Test
    public void isInputValidOperator() {
        Assert.assertTrue(OperatorUtil.isInputValidOperator(new String[]{"+","-","*","/","clear","undo","sqrt"}));
        Assert.assertFalse(OperatorUtil.isInputValidOperator(new String[]{"&"}));
    }

    @Test(expected = RPNException.class)
    public void checkStack() throws RPNException {
        OperatorUtil.checkStack(new Stack<BigDecimal>(),"+");
    }

    @Test
    public void isEmpty() {
        Assert.assertTrue(OperatorUtil.isEmpty(""));
        Assert.assertTrue(OperatorUtil.isEmpty(" "));
        Assert.assertFalse(OperatorUtil.isEmpty(" d"));
    }

}