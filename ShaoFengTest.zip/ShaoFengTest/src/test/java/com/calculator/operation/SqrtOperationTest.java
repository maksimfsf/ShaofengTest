package com.calculator.operation;

import com.calculator.OperationEnum;
import com.calculator.RPNException;
import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;
import org.junit.Assert;
import org.junit.Test;

import java.math.BigDecimal;

/*
 *@author Shaofeng
 *@date 2020/12/18 22:19
 *note:
 */public class SqrtOperationTest {

    @Test
    public void calculate() {
        StackWrapper<BigDecimal, OperationWrapper> stackWrapper = new StackWrapper<>();
        stackWrapper.getRpnStack().push(new BigDecimal("16"));
        stackWrapper.getRpnStack().push(new BigDecimal("16"));
        stackWrapper.setInput("sqrt");
        CalOperation ao = OperationEnum.getOperationByOperator("sqrt");
        try {
            ao.calculate(stackWrapper);
            Assert.assertEquals(new BigDecimal("4"),stackWrapper.getRpnStack().pop());
        } catch (RPNException e) {
            e.printStackTrace();
        }
    }
}