package com.calculator.operation;

import com.calculator.OperationEnum;
import com.calculator.RPNException;
import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;
import org.junit.Assert;
import org.junit.Test;

import java.math.BigDecimal;

/*
 *@author Shaofeng
 *@date 2020/12/18 22:18
 *note:
 */public class DefaultOperationTest {

    @Test
    public void calculate() {
        StackWrapper<BigDecimal, OperationWrapper> stackWrapper = new StackWrapper<>();
        stackWrapper.getRpnStack().push(new BigDecimal("5"));
        stackWrapper.getRpnStack().push(new BigDecimal("2"));
        stackWrapper.setInput("1");
        CalOperation ao = OperationEnum.getOperationByOperator("1");
        try {
            ao.calculate(stackWrapper);
            Assert.assertEquals(new BigDecimal("1"),stackWrapper.getRpnStack().pop());
        } catch (RPNException e) {
            e.printStackTrace();
        }
    }
}