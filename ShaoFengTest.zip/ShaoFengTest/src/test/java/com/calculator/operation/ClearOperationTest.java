package com.calculator.operation;

import com.calculator.OperationEnum;
import com.calculator.RPNException;
import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;
import org.junit.Assert;
import org.junit.Test;

import java.math.BigDecimal;

/*
 *@author Shaofeng
 *@date 2020/12/18 22:18
 *note:
 */public class ClearOperationTest {

    @Test
    public void calculate() {

        StackWrapper<BigDecimal, OperationWrapper> stackWrapper = new StackWrapper<>();
        stackWrapper.getRpnStack().push(new BigDecimal("5"));
        stackWrapper.getRpnStack().push(new BigDecimal("2"));
        stackWrapper.setInput("clear");
        CalOperation co = OperationEnum.getOperationByOperator("clear");
        try {
            co.calculate(stackWrapper);
            Assert.assertTrue(stackWrapper.getRpnStack().isEmpty());
        } catch (RPNException e) {
            e.printStackTrace();
        }
    }
}