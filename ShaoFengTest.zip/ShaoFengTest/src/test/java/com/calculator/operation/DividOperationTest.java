package com.calculator.operation;

import com.calculator.OperationFactory;
import com.calculator.RPNException;
import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;
import org.junit.Assert;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

/*
 *@author Shaofeng
 *@date 2020/12/18 22:18
 *note:
 */public class DividOperationTest {

    @Test
    public void calculate() {
        StackWrapper<BigDecimal, OperationWrapper> stackWrapper = new StackWrapper<>();
        stackWrapper.getRpnStack().push(new BigDecimal("6"));
        stackWrapper.getRpnStack().push(new BigDecimal("2"));
        stackWrapper.setInput("/");
        CalOperation ao = OperationFactory.getOperation("/");
        try {
            ao.calculate(stackWrapper);
            Assert.assertEquals(new BigDecimal("3"),stackWrapper.getRpnStack().pop());
        } catch (RPNException e) {
            e.printStackTrace();
        }
    }
}