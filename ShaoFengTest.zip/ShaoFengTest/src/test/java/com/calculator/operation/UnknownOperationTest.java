package com.calculator.operation;

import com.calculator.OperationFactory;
import com.calculator.RPNException;
import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;
import org.junit.Assert;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

/*
 *@author Shaofeng
 *@date 2020/12/18 22:19
 *note:
 */public class UnknownOperationTest {

    @Test(expected = RPNException.class)
    public void calculate() throws RPNException {
        StackWrapper<BigDecimal, OperationWrapper> stackWrapper = new StackWrapper<>();
        stackWrapper.getRpnStack().push(new BigDecimal("5"));
        stackWrapper.getRpnStack().push(new BigDecimal("2"));
        stackWrapper.setInput("&");
        CalOperation ao = OperationFactory.getOperation("&");
         ao.calculate(stackWrapper);

    }
}