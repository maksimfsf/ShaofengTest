package com.calculator;

import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;
import org.junit.After;
import org.junit.Before;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Scanner;

/*
 *@author Shaofeng
 *@date 2020/12/18 16:09
 *note:
 */public class MainCalculatorTest {
    /*private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    @Before
    public void setUpStreams(){
       System.setOut(new PrintStream(outContent));
    }
    @After
    public void cleanUpStreams() {
        System.setOut(null);
    }*/


   /* @org.junit.Test
    public void main() throws IOException, InterruptedException {
        String data = "5 2\r\n";
        InputStream stdin = System.in;
        try {
            System.setIn(new ByteArrayInputStream(data.getBytes()));
            Scanner scanner = new Scanner(System.in);
            //MainCalculator.main(new String[0]);
            System.out.println(scanner.nextLine());
        } finally {
            System.setIn(stdin);
        }
    }*/

    @org.junit.Test
    public void testCalculateProcess() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, InstantiationException {
        Class<MainCalculator> clz = MainCalculator.class;
        Object obj = clz.newInstance();
        Method method = clz.getDeclaredMethod("calculateProcess", new Class[]{StackWrapper.class,String[].class});
        method.setAccessible(true);
        StackWrapper<BigDecimal, OperationWrapper> sw = new StackWrapper<>();
        Object result = method.invoke(obj, new Object[]{sw,new String[]{"2","5"}});
        //System.out.println("out content:"+outContent.toString());
    }


    @org.junit.Test
    public void testCalculateProcess_sqrt() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, InstantiationException {

        Class<MainCalculator> clz = MainCalculator.class;
        Object obj = clz.newInstance();
        Method method = clz.getDeclaredMethod("calculateProcess", new Class[]{StackWrapper.class,String[].class});
        method.setAccessible(true);
        StackWrapper<BigDecimal, OperationWrapper> sw = new StackWrapper<>();
        Object result = method.invoke(obj, new Object[]{sw,new String[]{"2","5","sqrt"}});
    }

    @org.junit.Test
    public void testCalculateProcess_clear() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, InstantiationException {

        Class<MainCalculator> clz = MainCalculator.class;
        Object obj = clz.newInstance();
        Method method = clz.getDeclaredMethod("calculateProcess", new Class[]{StackWrapper.class,String[].class});
        method.setAccessible(true);
        StackWrapper<BigDecimal, OperationWrapper> sw = new StackWrapper<>();
        Object result = method.invoke(obj, new Object[]{sw,new String[]{"2","5","clear"}});
    }

    @org.junit.Test
    public void testCalculateProcess_undo() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, InstantiationException {

        Class<MainCalculator> clz = MainCalculator.class;
        Object obj = clz.newInstance();
        Method method = clz.getDeclaredMethod("calculateProcess", new Class[]{StackWrapper.class,String[].class});
        method.setAccessible(true);
        StackWrapper<BigDecimal, OperationWrapper> sw = new StackWrapper<>();
        Object result = method.invoke(obj, new Object[]{sw,new String[]{"2","5","undo"}});
    }
}