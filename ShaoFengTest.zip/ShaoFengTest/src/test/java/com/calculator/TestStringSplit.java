package com.calculator;

/*
 *@author Shaofeng
 *@date 2020/12/18 17:57
 *note:
 */

public class TestStringSplit {
    public static void main(String[] args) {
        //String b = "1 2 3 * 5 + * * 6 5";
        String b = "  1 2  -3 ";

        System.out.println("before："+b);
        System.out.println("before：------>"+b.length());
        String [] c = b.split(" ");
        System.out.println("after：------>"+c.length);
        for (int i=0; i<c.length ;i++){
            System.out.println(c[i]);
        }


    }
}
