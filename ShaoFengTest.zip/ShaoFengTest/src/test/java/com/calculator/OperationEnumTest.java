package com.calculator;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

/*
 *@author Shaofeng
 *@date 2020/12/18 16:42
 *note:
 */public class OperationEnumTest {


    @Test
    public void getTypeByOperator() {
        Assert.assertEquals(OperationEnum.UNKNOWN,OperationEnum.getTypeByOperator("xxxx"));
        Assert.assertEquals(OperationEnum.CLEAR,OperationEnum.getTypeByOperator("clear"));
        Assert.assertEquals(OperationEnum.UNDO,OperationEnum.getTypeByOperator("undo"));
        Assert.assertEquals(OperationEnum.INSERT,OperationEnum.getTypeByOperator("11"));
        Assert.assertEquals(OperationEnum.DIVID,OperationEnum.getTypeByOperator("/"));
        Assert.assertEquals(OperationEnum.MUTIP,OperationEnum.getTypeByOperator("*"));
        Assert.assertEquals(OperationEnum.SQRT,OperationEnum.getTypeByOperator("sqrt"));
        Assert.assertEquals(OperationEnum.MINUS,OperationEnum.getTypeByOperator("-"));
        Assert.assertEquals(OperationEnum.PLUS,OperationEnum.getTypeByOperator("+"));
    }
}