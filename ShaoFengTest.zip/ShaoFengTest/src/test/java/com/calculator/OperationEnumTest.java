package com.calculator;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

/*
 *@author Shaofeng
 *@date 2020/12/18 16:42
 *note:
 */public class OperationEnumTest {

    @Test
    public void getTypeByOperator() {
        Assert.assertEquals(OperationEnum.UNKNOWN.getOperation(),OperationEnum.getOperationByOperator("xxxx"));
        Assert.assertEquals(OperationEnum.CLEAR.getOperation(),OperationEnum.getOperationByOperator("clear"));
        Assert.assertEquals(OperationEnum.UNDO.getOperation(),OperationEnum.getOperationByOperator("undo"));
        Assert.assertEquals(OperationEnum.INSERT.getOperation(),OperationEnum.getOperationByOperator("11"));
        Assert.assertEquals(OperationEnum.DIVID.getOperation(),OperationEnum.getOperationByOperator("/"));
        Assert.assertEquals(OperationEnum.MUTIP.getOperation(),OperationEnum.getOperationByOperator("*"));
        Assert.assertEquals(OperationEnum.SQRT.getOperation(),OperationEnum.getOperationByOperator("sqrt"));
        Assert.assertEquals(OperationEnum.MINUS.getOperation(),OperationEnum.getOperationByOperator("-"));
        Assert.assertEquals(OperationEnum.PLUS.getOperation(),OperationEnum.getOperationByOperator("+"));
    }
}