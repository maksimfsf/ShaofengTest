package com.calculator;
/*
 *@author Shaofeng
 *@date 2020/12/18 14:42
 *note:
 */

public class RPNException extends Exception{
    private String operatorName;
    public RPNException(String operatorName){
        this.operatorName = operatorName;
    }
}
