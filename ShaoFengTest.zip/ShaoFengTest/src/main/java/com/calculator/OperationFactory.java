package com.calculator;
/*
 *@author Shaofeng
 *@date 2020/12/18 14:44
 *note:
 */

import com.calculator.operation.*;

import java.util.HashMap;
import java.util.Map;

import static com.calculator.OperationEnum.*;

public class OperationFactory {

    private static Map<OperationEnum, CalOperation> map = new HashMap<>();

    static {
        map.put(PLUS,new AddOperation());
        map.put(MINUS,new MinusOperation());
        map.put(MUTIP,new MultipOperation());
        map.put(DIVID,new DividOperation());
        map.put(CLEAR,new ClearOperation());
        map.put(UNDO,new UndoOperation());
        map.put(SQRT,new SqrtOperation());
        map.put(INSERT,new DefaultOperation());
        map.put(UNKNOWN,new UnknownOperation());
    }

    public static CalOperation getOperation(String operator) {
        CalOperation operation = map.get(UNKNOWN);
        OperationEnum operEnum = getTypeByOperator(operator);
        switch (operEnum) {
            case INSERT:
                operation = map.get(INSERT);
                break;
            case PLUS:
                operation = map.get(PLUS);
                break;
            case MINUS:
                operation = map.get(MINUS);
                break;
            case MUTIP:
                operation = map.get(MUTIP);
                break;
            case DIVID:
                operation = map.get(DIVID);
                break;
            case UNDO:
                operation = map.get(UNDO);
                break;
            case CLEAR:
                operation = map.get(CLEAR);
                break;
            case SQRT:
                operation = map.get(SQRT);
                break;
        }
        return operation;
    }


}
