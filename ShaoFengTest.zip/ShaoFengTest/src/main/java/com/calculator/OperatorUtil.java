package com.calculator;

/*
 *@author Shaofeng
 *@date 2020/12/18 14:46
 *note:
 */

import com.calculator.model.OperationWrapper;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

public class OperatorUtil {

    public static final int STACK_STORE_PRECISION = 15;
    public static final int CONSOLE_SHOW_PRECISION = 10;

    public static String SPACE =  " ";

    private static Set<String> validOperatorSet = new HashSet<>();

    static {
        validOperatorSet.add(OperationEnum.PLUS.getOperator());
        validOperatorSet.add(OperationEnum.MINUS.getOperator());
        validOperatorSet.add(OperationEnum.MUTIP.getOperator());
        validOperatorSet.add(OperationEnum.DIVID.getOperator());
        validOperatorSet.add(OperationEnum.SQRT.getOperator());
        validOperatorSet.add(OperationEnum.UNDO.getOperator());
        validOperatorSet.add(OperationEnum.CLEAR.getOperator());
        //validOperatorSet.add(OperationEnum.INSERT.getOperator());
        //validOperatorSet.add(SPACE);
    }

    /*
     * check string if numeric
     * */
    public static boolean isNumeric(String str) {
        if (OperationEnum.MINUS.getOperator().equals(str)
                || OperationEnum.PLUS.getOperator().equals(str)) return false;
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        return pattern.matcher(str).matches();
    }

    public static boolean isValidInput(String inputString) {
        return validOperatorSet.contains(inputString) || isNumeric(inputString);
    }

    /*
     * check if the input strings contains invalid operator.
     * */
    public static boolean isInputValidOperator(String[] inputStrs) {
        return IntStream.range(0, inputStrs.length).allMatch(i ->
                validOperatorSet.contains(inputStrs[i].trim()) || isNumeric(inputStrs[i].trim()));
    }

    public static void checkStack(Stack<BigDecimal> stack, String input) throws RPNException {
        if (stack.isEmpty()) throw new RPNException(input);
    }

    public static void checkStack(Stack<BigDecimal> stack, String input,BigDecimal popValue) throws RPNException {
        if (stack.isEmpty()){
            stack.push(popValue);
            throw new RPNException(input);
        }
    }

    public static boolean isEmpty(String inputStr) {
        return inputStr == null || "".equals(inputStr.trim());
    }


    /*
     * print alert message to console
     * */
    public static void printAlertMsg(String input, int index) {
        StringBuilder msg = new StringBuilder();
        msg.append("operator ");
        msg.append(input);
        msg.append(" (position: ");
        msg.append(index*2+1);
        msg.append("): insufficient parameters.");
        System.out.println(msg.toString());
    }

    /*
     * format and print the stack result to console
     * */
    public static void printStack(Stack<BigDecimal> resStack) {
        System.out.print("stack: ");
        if (resStack == null || resStack.isEmpty()) {
            System.out.println();
            return;
        }
        Enumeration<BigDecimal> items = resStack.elements();
        while (items.hasMoreElements()) {
            BigDecimal tmpItem = items.nextElement();
            if (new BigDecimal(tmpItem.intValue()).compareTo(tmpItem) != 0) {//not int value, need format.
                tmpItem = tmpItem.setScale(CONSOLE_SHOW_PRECISION, RoundingMode.HALF_UP);
            }
            System.out.print(tmpItem.stripTrailingZeros().toPlainString() + OperatorUtil.SPACE);
        }
        System.out.println();
    }

    /*
    * push current operation to the undo stack
    * */
    public static void pushToUndoStack(BigDecimal left,BigDecimal right,String input,Stack<OperationWrapper> undoStack){
        OperationWrapper ow = new OperationWrapper(left,right,input);
        undoStack.push(ow);
    }

}
