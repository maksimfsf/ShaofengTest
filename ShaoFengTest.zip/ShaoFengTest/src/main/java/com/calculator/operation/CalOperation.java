package com.calculator.operation;
/*
 *@author Shaofeng
 *@date 2020/12/18 14:39
 *note:
 */

import com.calculator.RPNException;
import com.calculator.model.StackWrapper;

public interface CalOperation<T,K> {
    void calculate(StackWrapper<T,K> stackWrapper) throws RPNException;
}

