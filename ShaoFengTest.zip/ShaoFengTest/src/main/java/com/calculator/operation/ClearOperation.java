package com.calculator.operation;

/*
 *@author Shaofeng
 *@date 2020/12/18 14:40
 *note:
 */

import com.calculator.RPNException;
import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;

import java.math.BigDecimal;

public class ClearOperation implements CalOperation<BigDecimal, OperationWrapper> {
    @Override
    public void calculate(StackWrapper<BigDecimal, OperationWrapper> stackWrapper) throws RPNException {
        while (!stackWrapper.getRpnStack().empty()) {
            stackWrapper.getRpnStack().pop();
        }

        while (!stackWrapper.getUndoStack().empty()) {
            stackWrapper.getUndoStack().pop();
        }
        return;
    }
}
