package com.calculator.operation;

/*
 *@author Shaofeng
 *@date 2020/12/18 14:40
 *note:
 */

import com.calculator.OperatorUtil;
import com.calculator.RPNException;
import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Stack;

public class SqrtOperation implements CalOperation<BigDecimal, OperationWrapper> {

    @Override
    public void calculate(StackWrapper<BigDecimal, OperationWrapper> stackWrapper) throws RPNException {
        Stack<BigDecimal> rpnStack = stackWrapper.getRpnStack();
        String input = stackWrapper.getInput();
        OperatorUtil.checkStack(rpnStack, input);
        BigDecimal number = rpnStack.pop();
        MathContext mc = new MathContext(OperatorUtil.STACK_STORE_PRECISION);
        BigDecimal squareRoot = number.sqrt(mc);
        rpnStack.push(squareRoot);

        OperatorUtil.pushToUndoStack(number, null, input, stackWrapper.getUndoStack());
        return;
    }
}
