package com.calculator.operation;

/*
 *@author Shaofeng
 *@date 2020/12/18 15:05
 *note:
 */

import com.calculator.OperatorUtil;
import com.calculator.RPNException;
import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;

import java.math.BigDecimal;

public class DefaultOperation implements CalOperation<BigDecimal, OperationWrapper> {

    @Override
    public void calculate(StackWrapper<BigDecimal, OperationWrapper> stackWrapper) throws RPNException {
        BigDecimal input = new BigDecimal(stackWrapper.getInput());
        stackWrapper.getRpnStack().push(input);//OOM Exception ??
        OperatorUtil.pushToUndoStack(null, null, stackWrapper.getInput(), stackWrapper.getUndoStack());
    }
}
