package com.calculator.operation;

/*
 *@author Shaofeng
 *@date 2020/12/18 14:40
 *note:
 */

import com.calculator.RPNException;
import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;

import java.math.BigDecimal;

public class UnknownOperation implements CalOperation<BigDecimal, OperationWrapper> {

    @Override
    public void calculate(StackWrapper stackWrapper) throws RPNException {
        throw new RPNException(stackWrapper.getInput());
    }
}
