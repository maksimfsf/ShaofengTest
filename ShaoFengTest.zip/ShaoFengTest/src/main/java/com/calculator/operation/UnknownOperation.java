package com.calculator.operation;

/*
 *@author Shaofeng
 *@date 2020/12/18 14:40
 *note:
 */

import com.calculator.RPNException;
import com.calculator.model.StackWrapper;

public class UnknownOperation implements CalOperation {

    @Override
    public void calculate(StackWrapper stackWrapper) throws RPNException {
        throw new RPNException(stackWrapper.getInput());
    }
}
