package com.calculator.operation;

/*
 *@author Shaofeng
 *@date 2020/12/18 14:40
 *note:
 */

import com.calculator.OperatorUtil;
import com.calculator.RPNException;
import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Stack;

public class DividOperation implements CalOperation<BigDecimal, OperationWrapper> {

    @Override
    public void calculate(StackWrapper<BigDecimal, OperationWrapper> stackWrapper) throws RPNException {
        Stack<BigDecimal> rpnStack = stackWrapper.getRpnStack();
        String input = stackWrapper.getInput();
        OperatorUtil.checkStack(rpnStack, input);
        BigDecimal right = rpnStack.pop();
        if (right.compareTo(BigDecimal.ZERO) == 0) {
            rpnStack.push(right);
            throw new RPNException(input);
        }
        OperatorUtil.checkStack(rpnStack, input, right);
        BigDecimal left = rpnStack.pop();
        MathContext mc = new MathContext(OperatorUtil.STACK_STORE_PRECISION);
        rpnStack.push(left.divide(right, mc));
        OperatorUtil.pushToUndoStack(left, right, input, stackWrapper.getUndoStack());
        return;
    }
}
