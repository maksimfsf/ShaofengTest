package com.calculator.operation;

/*
 *@author Shaofeng
 *@date 2020/12/18 14:40
 *note:
 */

import com.calculator.OperatorUtil;
import com.calculator.RPNException;
import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;

import java.math.BigDecimal;
import java.util.Stack;

public class UndoOperation implements CalOperation<BigDecimal, OperationWrapper> {

    @Override
    public void calculate(StackWrapper<BigDecimal, OperationWrapper> stackWrapper) throws RPNException {
        Stack<BigDecimal> spnStack = stackWrapper.getRpnStack();
        OperatorUtil.checkStack(spnStack, stackWrapper.getInput());
        spnStack.pop();
        Stack<OperationWrapper> undoStack = stackWrapper.getUndoStack();
        if (!undoStack.isEmpty()) {
            OperationWrapper previousOperation = undoStack.pop();
            if (previousOperation.getLeftValue() != null) {
                spnStack.push(previousOperation.getLeftValue());
            }
            if (previousOperation.getRightValue() != null) {
                spnStack.push(previousOperation.getRightValue());
            }
        }
    }
}
