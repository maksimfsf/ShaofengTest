package com.calculator;

/*
 *@author Shaofeng
 *@date 2020/12/18 15:15
 *note:
 */

import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;
import com.calculator.operation.CalOperation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.Stack;

public class MainCalculator {

    public static void main(String[] args) {
        welcome();
        BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
        String inputStr = null;
        boolean exitFlag = false;
        StackWrapper<BigDecimal, OperationWrapper> stackWrapper = new StackWrapper<>();

        while (!exitFlag) {
            try {
                inputStr = buffer.readLine();
                if ("EXIT".equals(inputStr)) {
                    exitFlag = true;
                    System.out.println("ByeBye! See you next time.");
                    continue;
                }
                if (OperatorUtil.isEmpty(inputStr)) continue;

                String[] inputArray = inputStr.split("\\s+");

                calculateProcess(stackWrapper, inputArray);

            } catch (IOException e) {
                System.out.println("Internal Error");
                System.exit(-1);
            }
        }
    }

    /*
    * Main process logic of RPN calculator
    * */
    private static void calculateProcess(StackWrapper<BigDecimal, OperationWrapper> stackWrapper, String[] inputArray) {
        for (int i = 0; i < inputArray.length; i++) {
            if (!OperatorUtil.isValidInput(inputArray[i])) {
                printAlertAndStack(stackWrapper.getRpnStack(), i, inputArray[i]);
                break;
            }

            if (OperatorUtil.isEmpty(inputArray[i])) {
                continue;
            }

            CalOperation<BigDecimal, OperationWrapper> operation = OperationFactory.getOperation(inputArray[i]);

            try {
                stackWrapper.setInput(inputArray[i]);
                operation.calculate(stackWrapper);
                if (i == inputArray.length - 1) {
                    OperatorUtil.printStack(stackWrapper.getRpnStack());
                }
            } catch (RPNException e) {
                printAlertAndStack(stackWrapper.getRpnStack(), i, inputArray[i]);
                break;
            }
        }
    }

    private static void printAlertAndStack(Stack<BigDecimal> calculatorStack, int i, String input) {
        OperatorUtil.printAlertMsg(input, i);
        OperatorUtil.printStack(calculatorStack);
    }

    private static void welcome() {
        System.out.println("##############################################################################################################################");
        System.out.println("Welcome! RPN Calculator is ready, please enter your input:");
        System.out.println("NOTE: only support below input operator: numeric, +, -, *, /, undo, clear, sqrt, ' '(space), other invalid input will exit. " +
                "\r\nIf you want exit, please input  'EXIT' to quit.");
        System.out.println("##############################################################################################################################");
    }
}
