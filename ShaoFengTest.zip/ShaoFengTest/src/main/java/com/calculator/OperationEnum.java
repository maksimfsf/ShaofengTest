package com.calculator;

import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;
import com.calculator.operation.*;

import java.math.BigDecimal;

/*
 *@author Shaofeng
 *@date 2020/12/18 14:45
 *note:
 */
public enum OperationEnum {

    PLUS("+", new AddOperation()),
    MINUS("-", new MinusOperation()),
    MUTIP("*", new MultipOperation()),
    DIVID("/", new DividOperation()),
    SQRT("sqrt", new SqrtOperation()),
    UNDO("undo", new UndoOperation()),
    CLEAR("clear", new ClearOperation()),
    UNKNOWN("x", new UnknownOperation()),
    INSERT("default", new DefaultOperation());

    String operator;
    CalOperation<BigDecimal, OperationWrapper> operation;

    OperationEnum(String oper, CalOperation<BigDecimal, OperationWrapper> operation) {
        this.operator = oper;
        this.operation = operation;
    }

    /*
     * get details operation action by the operator
     * sample, "+", will return AddOperation
     * */
    public static CalOperation<BigDecimal, OperationWrapper> getOperationByOperator(String oper) {
        if (oper == null) {
            return UNKNOWN.getOperation();
        }
        if (OperatorUtil.isNumeric(oper)) {
            return INSERT.getOperation();
        } else {
            for (OperationEnum opE : values()) {
                if (opE == INSERT) continue;//not in include insert
                if (opE.getOperator().equals(oper)) {
                    return opE.getOperation();
                }
            }
        }
        return UNKNOWN.getOperation();
    }

    public String getOperator() {
        return operator;
    }

    public CalOperation getOperation() {
        return operation;
    }
}
