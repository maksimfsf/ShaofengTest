package com.calculator;

/*
 *@author Shaofeng
 *@date 2020/12/18 14:45
 *note:
 */
public enum OperationEnum {

    PLUS("+"),
    MINUS("-"),
    MUTIP("*"),
    DIVID("/"),
    SQRT("sqrt"),
    UNDO("undo"),
    CLEAR("clear"),
    UNKNOWN("x"),
    INSERT("default");

    String operator;

    OperationEnum(String oper) {
        this.operator = oper;
    }

    public String getOperator() {
        return operator;
    }

    public static OperationEnum getTypeByOperator(String oper) {
        if (oper == null) {
            return UNKNOWN;
        }
        if (OperatorUtil.isNumeric(oper)) {
            return INSERT;
        } else {
            for (OperationEnum opE : values()) {
                if (opE == INSERT) continue;//not in include insert
                if (opE.getOperator().equals(oper)) {
                    return opE;
                }
            }
        }
        return UNKNOWN;
    }
}
