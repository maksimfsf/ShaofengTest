package com.calculator;

import com.calculator.model.OperationWrapper;
import com.calculator.model.StackWrapper;
import com.calculator.operation.*;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

/*
 *@author Shaofeng
 *@date 2020/12/18 14:45
 *note:
 */
public enum OperationEnum {

    PLUS("+", new AddOperation()),
    MINUS("-", new MinusOperation()),
    MULTIP("*", new MultipOperation()),
    DIVID("/", new DividOperation()),
    SQRT("sqrt", new SqrtOperation()),
    UNDO("undo", new UndoOperation()),
    CLEAR("clear", new ClearOperation()),
    UNKNOWN("x", new UnknownOperation()),
    INSERT("default", new DefaultOperation());

    String operator;
    CalOperation<BigDecimal, OperationWrapper> operation;
    private static Map<String, CalOperation<BigDecimal, OperationWrapper>> operMap = new HashMap<>();

    static {
        //not in include insert
        Arrays.stream(values()).filter(opE -> opE != INSERT && opE != UNKNOWN)
                .forEach(opE -> operMap.put(opE.getOperator(), opE.getOperation()));
    }

    OperationEnum(String oper, CalOperation<BigDecimal, OperationWrapper> operation) {
        this.operator = oper;
        this.operation = operation;
    }

    /*
     * get details operation action by the operator
     * sample, "+", will return AddOperation
     * */
    public static CalOperation<BigDecimal, OperationWrapper> getOperationByOperator(String oper) {
        CalOperation<BigDecimal, OperationWrapper> co = null;
        if (OperatorUtil.isNumeric(oper)) {
            return INSERT.getOperation();
        } else {
            co = operMap.get(oper);
        }
        return co == null ? UNKNOWN.getOperation() : co;
    }

    public String getOperator() {
        return operator;
    }

    public CalOperation getOperation() {
        return operation;
    }
}
