package com.calculator.model;
/*
 *@author Shaofeng
 *@date 2020/12/18 19:37
 *note:
 */

import java.util.Stack;

public class StackWrapper<T,K> {
    private String input;
    private Stack<T> rpnStack = new Stack<>();
    private Stack<K> undoStack = new Stack<>();

    public Stack<T> getRpnStack() {
        return rpnStack;
    }

    public Stack<K> getUndoStack() {
        return undoStack;
    }

    public String getInput() {
        return input;
    }

    public void setInput(String input) {
        this.input = input;
    }
}

