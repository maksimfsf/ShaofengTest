package com.calculator.model;
/*
 *@author Shaofeng
 *@date 2020/12/18 20:10
 *note:
 */

import java.math.BigDecimal;

public class OperationWrapper {
    BigDecimal leftValue;
    BigDecimal rightValue;
    String input;

    public OperationWrapper(BigDecimal leftValue, BigDecimal rightValue, String operation) {
        this.leftValue = leftValue;
        this.rightValue = rightValue;
        this.input = operation;
    }

    public BigDecimal getLeftValue() {
        return leftValue;
    }

    public void setLeftValue(BigDecimal leftValue) {
        this.leftValue = leftValue;
    }

    public BigDecimal getRightValue() {
        return rightValue;
    }

    public void setRightValue(BigDecimal rightValue) {
        this.rightValue = rightValue;
    }

    public String getInput() {
        return input;
    }

    public void setInput(String input) {
        this.input = input;
    }
}
