
NOTE:
1. Required jDK 9
2. MainClass:com.calculator.MainCalculator
3. run it in idea or after package jar file

jar run command: java -jar ShaofengTest-1.0.jar

1.1 change, use OperationEnum as the operation handler selector.